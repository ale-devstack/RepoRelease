from setuptools import setup, find_packages

setup(
    name="RepoReleses",                             # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Alejandro Hernandez",                   # Tu nombre
    author_email="ahernandez.devstack@gmail.com",   # Tu correo electrónico
    url="https://github.com/ale-devstack/RepoReleses", # URL del proyecto
)